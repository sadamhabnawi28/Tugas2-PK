Buka Intelij lalu open project file "Project Intelij no 1" lalu Run program tersebut
setelah itu buka PgAdmin lalu buka server dengan port 5432 lalu jalakan program tabel "mahasiswa.sql" pada querry tool
selanjutnya masukan id, nama mahasiswa yang diingikan hingga data terkirim, lalu buka querry tool pada pgadmin dan jalankan program "data mahasiswa.sql"