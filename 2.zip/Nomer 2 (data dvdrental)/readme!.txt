simpan data dvdrental.tar ke server pada postgreSQL di pg admin
<nama server> -> restore -> simpan dvdrental tar
lalu jalakan program pada querry tool dengan .sql berikut